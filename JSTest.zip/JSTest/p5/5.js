
$(document).ready(init);


function init () {
	// body...
	console.log("Hello");
	$("#code").click(content);
}

function content () {
	// insert HTML

	$("#content").html("<p>Hello!!!</p>");

}


