



var b,h,f,c;
h=prompt("Ingrese altura: ","5");//por default el valor 5 
b=prompt("Ingrese base: ","15");//por defalut el valor 15
for(f=0;f<h;f++)
{	for(c=0;c<b;c++) 
 
{ 
document.write("*");//imprimimos los * 
} 
document.write("<br>"); 
/*esta parte es importante ya que sin ella 
no se podria ver como rectangulo*/ 
} 