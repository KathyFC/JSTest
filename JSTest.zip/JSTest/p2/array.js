/*Se pide una función que recibe un arreglo como parámetro y devuelva una copia del arreglo.*/

    var array = [1990, 8, 19];
	
	var arr2 = [].concat(array);	

	// body...
	console.log(array);
	// [1990, 8, 19]
	console.log(arr2);
	// [1990, 8, 19]
	

