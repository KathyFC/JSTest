
/*Se ha creado el siguiente algoritmo que busca que el usuario ingrese elementos hasta que indique lo contrario, para lo cual
ingresará la palabra "fin". Este algoritmo no está completo, se pide arreglarlo.*/

/* el algoritmo funciona, solo que el usuario no sabe que debe digitar "fin" para salir, solo se le agrego eso, puesto que no se menciona si hay que sumar o nolos valores ingresados*/
var suma=0;
do
	var ingreso = prompt('ingresa un número, si NO deseas seguir añadiendo numeros solo escribe "fin" ');
	
while (isNaN(ingreso)==false || ingreso != "fin" );
console.log(suma);